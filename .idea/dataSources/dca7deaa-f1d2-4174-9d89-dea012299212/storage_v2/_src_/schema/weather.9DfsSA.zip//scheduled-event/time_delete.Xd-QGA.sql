create definer = root@localhost event time_delete on schedule
  every '1' SECOND
    starts '2018-01-11 20:40:21'
  enable
  do
  delete from result where outtime <  (CURRENT_TIMESTAMP());

